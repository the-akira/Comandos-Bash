#!/bin/bash

sistema="Linux"
linguagem="C"

echo "O ${sistema} foi escrito com a linguagem ${linguagem}"