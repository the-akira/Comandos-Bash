#!/bin/bash

echo "Quanto tempo de espera?"
read time
sleep $time
echo "Esperados $time segundos!"