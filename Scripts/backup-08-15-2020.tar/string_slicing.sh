#!/bin/bash

string="Programação com Bash"
substring=${string:15}
echo $substring