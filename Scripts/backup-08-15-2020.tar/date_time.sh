#!/bin/bash

ano=`date +%Y`
mes=`date +%m`
dia=`date +%d`
hora=`date +%H`
minuto=`date +%M`
segundo=`date +%S`

echo `date`
echo "Data atual: $dia-$mes-$ano"
echo "Horário atual: $hora:$minuto:$segundo"