#!/bin/bash

echo -n "Informe seu nome: "
read nome

echo "Você informou $nome com ${#nome} caracteres"